import Link from "next/link";
import AddToCartButton from "./buttons/AddToCart";

function ProductCard({product}) {
  return (
    <article className="pc">
      <span className="od">{(100 - (product.offer_price / product.base_price * 100)).toFixed(2)}% Off</span>
      <Link href={`/products/${product.slug}`}>
        <div className="im">
          <img
            className="product-image"
            src={product.thumbnail_url}
            alt={product.name}
          />
        </div>
        <h3>{product.name}</h3>
      </Link>
      <div className="mt">{product.brand.name}</div>
      <div className="pr">
        <b>৳ {product.offer_price}</b>
        <s>৳ {product.base_price}</s>
      </div>
      <form action="/cart/add" method="post">
        <AddToCartButton product={product}/>
      </form>
    </article>
  );
}

export default ProductCard;
